import 'package:flutter/material.dart';

class DrawerPainel extends StatefulWidget {
  DrawerPainel({Key key}): super(key: key);

  @override
  _DrawerPainelState createState() => _DrawerPainelState();
}

class _DrawerPainelState extends State<DrawerPainel> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
